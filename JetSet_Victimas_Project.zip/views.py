
from django.shortcuts import render
from django.core.files.storage import FileSystemStorage

def subir_imagen(request):
    if request.method == 'POST' and request.FILES['imagen']:
        imagen = request.FILES['imagen']
        fs = FileSystemStorage(location='media/uploads/')
        filename = fs.save(imagen.name, imagen)
        url = fs.url(filename)
        return render(request, 'subir.html', {'url': url})
    return render(request, 'subir.html')
